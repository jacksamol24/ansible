#! /bin/bash
# Done by : DJ,AJ
# Done on : 27 October 2015
# Purpose : To impose security baselines as per standards of Atos for RHEL 6.7 and CentOS 6.7 servers
# Document : MSP-GAD-0244 Technical Security Specifications Server Unix.pdf
# Doc Provider : PAAS , Compose Team
# Log File Path : /tmp
# Last Updated on : 3 August 2016
clear

endFC="\033[0m"
FCred="\033[31m"
FCgreen="\033[32m"
FCyellow="\033[33m"

logVal=1
if [ $logVal != 1 ]; then
{
        echo -e "$FCyellow Logging output for $0 is disabled. No Log File would be created $endFC"
        logFileAbsPath=' '
}
else
{
        #date=`date +%D_%T`
        logFilePath="/tmp"
        logFileAbsPath=$logFilePath"/SecurityLogs.logs"
        echo "------------------------------------------------------------------------------------------------" | tee -a  $logFileAbsPath
        date | tee -a  $logFileAbsPath
}
fi

check_file_exists()
{
        if [ -e $1 ]; then
        {
                echo -e "$FCgreen $1 file exists $endFC" | tee -a  $logFileAbsPath
                return 0
        }
        else
        {
                echo -e "$FCgreen $1 does not exists $endFC" | tee -a $logFileAbsPath
                return 1
        }
        fi
}

## Part 1 : Authorization and Authentication

## Below function checks and sets the Maximum Password Age
Passwd_Maxi_Age()
{
        checkValue()
        {
                val=`grep -i pass_max_days $absPath | grep -v "#" | awk -F" " '{print $2}' | xargs`
                valAsPerStd=92
                if [ "$val" != "$valAsPerStd" ]; then
                {
                        echo -e "$FCgreen Value set for maximum age of password is not as per standards : $val $endFC" | tee -a $logFileAbsPath
                        setValue
                }
                else
                {
                        echo -e "$FCgreen Value set for maximum age of password is as per the standards : $val $endFC" | tee -a $logFileAbsPath
                }
                fi
        }
        setValue()
        {
                echo "Deleting the old value and Setting it now" |  tee -a $logFileAbsPath
                #sed -i '/PASS_MAX_DAYS/ s/^/#/g' $absPath
                sed -i '/PASS_MAX_DAYS/d' $absPath
                if [ $? -eq 0 ]; then
                {
                        echo "PASS_MAX_DAYS  92" >> $absPath
                        checkValue
                }
                else
                {
                        echo -e "$FCred Could not set the value for PASS_MAX_DAYS $endFC" | tee -a $logFileAbsPath
                }
                fi
        }
        ##check if login.defs exists
        fileName="login.defs"
        filePath="/etc"
        absPath=$filePath"/"$fileName
        check_file_exists $absPath
   if [ $? -eq 0 ]; then
        {
                # Check the value for PASS_MAX_DAYS in login.defs file
                checkValue
        }
        else
        {
                echo -e "$FCred File $absPath does not exists $endFC" | tee -a $logFileAbsPath
                echo -e "$FCred Could not set the maximum password age for any user on this server $endFC" | tee -a  $logFileAbsPath
        }
        fi
}


### Below function checks if blank passwords are allowed or not
BlankPassNotAllowed()
{
        fileName="sshd_config"
        filePath="/etc/ssh"
        absPath=$filePath"/"$fileName
        string="PermitEmptyPasswords no"
        check_file_exists $absPath
        if [ $? -eq 0 ]; then
        {
                grep "$string" $absPath | grep -v "#" > /dev/null
                if [ $? -eq 0 ]; then
                {
                        echo -e "$FCgreen Blank Passwords not allowed is enabled $endFC" | tee -a $logFileAbsPath
                }
                else
                {
                        echo -e "$FCgreen Setting blank password not allowed in $fileName $endFC" | tee -a $logFileAbsPath
                        grep "$string" $absPath | grep -v "#" > /dev/null
                        if [ $? -eq 1 ]; then
                        {
                                echo "PermitEmptyPasswords no" >> $absPath
                                echo -e "$FCgreen Blank Passwords not allowed is enabled $endFC" | tee -a $logFileAbsPath
                        }
                        fi
                }
                fi

        }
        else
        {
                echo -e "$FCred Could not find the file $absPath $endFC" | tee -a $logFileAbsPath
                echo -e "$FCred Blank Password not allowed is not enabled $endFC" | tee -a $logFileAbsPath
        }
        fi
}

## Below function sets the password complexity for all the users
PasswordComplexity()
{
        fileName="system-auth"
        filePath="/etc/pam.d"
        absPath=$filePath"/"$fileName
	check_file_exists $absPath
        if [ $? -eq 0 ]; then
        {
        	grep -i "pam_cracklib.so" $absPath | grep -v "#" > /dev/null
                if [ $? -eq 0 ]; then
                {
			#replace the pam_craclib.so with all character credits
			sed -i '/pam_cracklib.so/ c password    required      pam_cracklib.so try_first_pass retry=3 type=  dcredit=-1 lcredit=-1 ucredit=-1 ocredit=-1"' $absPath
			if [ $? -eq 0 ]; then               		
			{
				 echo -e "$FCgreen Successfully changed setting for password complexity $endFC" | tee -a $logFileAbsPath
                        }
                        else
                        {
                                echo -e "$FCred Could not change the settings for password complexity $endFC" | tee -a $logFileAbsPath
                        }
                        fi
 
		}
                else
                {

                	#add a new line of pam_cracklib.so for password complexity
			echo -e "$FCyellow password complezity is not set already... setting in now! $endFC" | tee -a $LogFileAbsPath
			sed -i $'/password/{i password    required      pam_cracklib.so try_first_pass retry=3 type=  dcredit=-1 lcredit=-1 ucredit=-1 ocredit=-1\n; :a;n;ba}' $absPath	
			 if [ $? -eq 0 ]; then
                        {
                                 echo -e "$FCgreen Successfully changed setting for password complexity $endFC" | tee -a $logFileAbsPath
                        }
                        else
                        {
                                echo -e "$FCred Could not change the settings for password complexity $endFC" | tee -a $logFileAbsPath
                        }
                        fi

		}
                fi
                
        }
        else
        {
                echo -e "$FCred Could not set password complexity as $absPath file does not exists.$endFC" | tee -a $logFileAbsPath
        }
        fi

}

## Below function sets the password history to 5 and does not allow users to use last 5 previously used passwords
passwordHistory()
{
        fileName="system-auth"
        filePath="/etc/pam.d"
        absPath=$filePath"/"$fileName
        check_file_exists $absPath
        string="sha512"
        if [ $? -eq 0 ]; then
        {
                grep -i "remember" $absPath > /dev/null
                if [ $? -eq 0 ]; then
                {
                        echo -e "$FCyellow Checking password history is already set $endFC" | tee -a $logFileAbsPath
                }
                else
                {
                        sed -i '/'$string'/ s/$/ remember=5/g' $absPath
                        if [ $? -eq 0 ]; then
                        {
                                echo -e "$FCgreen Successfully changed setting to not allow users to use their last used passwords $endFC" | tee -a $logFileAbsPath
                        }
                        else
                        {
                                echo -e "$FCred Could not change the settings to not allow users to use their last 5 passwords $endFC" | tee -a $logFileAbsPath
                        }
                        fi
                }
                fi
        }
        else
        {
                echo -e "$FCred Could not find the file $fileName on $absPath $endFC" | tee -a $logFileAbsPath
        }
        fi
}

## Below function sets number of minimum days before which user can change the password
passwdMinDays()
{
        fileName="login.defs"
        filePath="/etc"
        absPath=$filePath"/"$fileName
        string="PASS_MIN_DAYS"
        check_file_exists $absPath
        if [ $? -eq 0 ]; then
        {
                val=`grep $string $absPath | grep -v "#" | awk -F" " '{print $2}'` > /dev/null
                if [ $val != 1 ]; then
                {
                        sed -i '/PASS_MIN_DAYS/ s/^/#/g' $absPath
                        if [ $? -eq 0 ]; then
                        {
                                echo "PASS_MIN_DAYS  1" >> $absPath
                                echo -e "$FCgreen Successfully set the miminum number of days before which user can change his password $endFC" | tee -a $logFileAbsPath
                        }
                        else
                        {
                                echo -e "$FCyellow Could not set the minimum number of days before which user can change the password $endFC" | tee -a $logFileAbsPath
                        }
                        fi
                }
                else
                {
                        echo -e "$FCyellow Minimum number of days before which user can change password is already set $endFC" | tee -a $logFileAbsPath
                }
                fi
        }
        else
        {
                echo -e "$FCred Could not find the file $fileName at $absPath $endFC" | tee -a $logFileAbsPath
        }
        fi
}

## Below function sets the minimum lenght of the password

passwdMinLength()
{
        fileName="login.defs"
        filePath="/etc"
        absPath=$filePath"/"$fileName
        string="PASS_MIN_LEN"
        check_file_exists $absPath
        setMinPasswd()
        {
                echo "PASS_MIN_LEN  7" >> $absPath
                echo -e "$FCgreen Successfully set the Minimum password length to 7 $endFC" | tee -a $logFileAbsPath

        }
        if [ $? -eq 0 ]; then
        {
                val=`grep $string $absPath | grep -v "#"`> /dev/null
                newval=`echo $val | awk -F" " '{print $2}'`
                if [ $newval -ne 7 ] || [ -z $newval ]; then
                {
                        echo -e "$FCyellow Setting the value for Minimum password length $endFC" |  tee -a $logFileAbsPath
                        if [ ! -z $newval ]; then
                        {
                        sed -i '/PASS_MIN_LEN/ s/^/#/g' $absPath
                                if [ $? -eq 0 ]; then
                                {
                                setMinPasswd
                                }
                                else
                                {
                                echo -e "$FCred oould not successfully set the minimum password length to 7 $endFC" | tee -a $logFileAbsPath
                                }
                                fi
                        }
                        else
                        {
                        setMinPasswd
                        }
                        fi
                }
                else
                {
                        echo -e "$FCyellow Value for Minimum password length is alredy set to 7 $endFC" | tee -a $logFileAbsPath
                }
				fi
        }
        else
        {
                echo -e "$FCred Could not find the file $fileName at $absPath $endFC" | tee -a $logFileAbsPath
        }
        fi
}

## Part 2 : Logging

## Below function enables logging for all authentication done on the dydtem
rsyslogAuth()
{
	fileName="secure"
	filePath="/var/log"
        absPath=$filePath"/"$fileName
        check_file_exists $absPath
	if [ $? -eq 0 ]; then
	{
		grep authpriv /etc/rsyslog.conf  | grep -v "#" | tail -1 > /dev/null
		if [ $? -eq 0 ]; then
		{
			echo -e "$FCyellow auth priv is already set for logging user authentication $endFC" | tee -a $logFileAbsPath
		}
		else
		{
			echo -e "$FCred auth priv is not set for logging user authentication $endFC" | tee -a $logFileAbsPath
			echo "authpriv.*                                             /var/log/secure" >> $absPath
			echo -e "$FCgreen auth priv is successfully set for logging user authentication $endFC" | tee -a $logFileAbsPath
		}
		fi
	}
	else
	{
		echo -e "$FCred Could not find the file $fileName at $absPath $endFC" | tee -a $logFileAbsPath
	}
	fi
		
}

## Below function will set defined permissions for some of the files
checkFilePerm()
{
	grubConf="/boot/grub2/grub.cfg"
	passwd="/etc/passwd"
	group="/etc/group"
	shadow="/etc/shadow"
	pamd="/etc/pam.d"
	chmod 600 $grubConf
	chmod 664 $passwd
	chmod 664 $group
	chmod 400 $shadow
	chmod 755 $pamd
	
	echo -e "$FCgreen Defined permissions are successfully set for the required system files $endFC" | tee -a $logFileAbsPath
}

## Below function will disable root login via ssh
disableRootLogin()
{
	fileName="sshd_config"
	filePath="/etc/ssh"
        absPath=$filePath"/"$fileName
        check_file_exists $absPath
	if [ $? -eq 0 ]; then
	{
		grep -i permitrootlogin /etc/ssh/sshd_config | grep -v "#" > /dev/null
		if [ $? -eq 0 ]; then
		{
			val=`grep -i permitrootlogin /etc/ssh/sshd_config | grep -v "#"` > /dev/null
			newval=`echo $val | awk -F" " '{print $2}'`
			if [ $newval != "no" ]; then
			{
				echo -e "$FCyellow Root login is permitted via ssh. Disabling it $endFC" |  tee -a $logFileAbsPath
				sed -i '/PermitRootLogin/ s/yes/no/g' $absPath
				echo -e "$FCgreen Successfully disbaled loging using root user via ssh $endFC" | tee -a $logFileAbsPath
				#systemctl restart sshd.service
				/etc/init.d/sshd restart
			}
			else
			{
				echo -e "$FCyellow Root login is already permitted via ssh $endFC" | tee -a $logFileAbsPath
			}
			fi
		}
		else
		{
			echo "PermitRootLogin  no" >> $absPath
			echo -e "$FCgreen Successfully disbaled loging using root user via ssh $endFC" | tee -a $logFileAbsPath
			#systemctl restart sshd.service
			/etc/init.d/sshd restart
		}
		fi
	}
	else
	{
		echo -e "$FCred Could not find the file $fileName at $absPath path $endFC" | tee -a $logFileAbsPath
	}
	fi
}

bashrcOwnership()
{
	parDir="/home"
	max=`ls -lrth /home | grep -v "total" | wc -l`
	tmpFile="/tmp/file"
	file=".bashrc"
	ls -lrth /home | grep -v "total"  | awk '{print $NF}' > $tmpFile
	for ((i=1;i<=$max;i++))
	do
		userDir=`head -$i $tmpFile | tail -1`
		cd $parDir/$userDir
		chown $userDir:$userDir $parDir/$userDir
	done
	rm -frv $tmpFile > /dev/null
	
	echo -e "$FCgreen owner/group of users .bashrc file is set to respective users $endFC" | tee -a $logFileAbsPath 

}


##Part 3 : Network Security

networkSecurity()
{
	fileName="sysctl.conf"
	filePath="/etc"
        absPath=$filePath"/"$fileName
	checkSetVal()
	{
		array=("net.ipv4.conf.all.accept_source_route" "net.ipv4.conf.all.forwarding" "net.ipv6.conf.all.forwarding" "net.ipv4.conf.all.mc_forwarding" "net.ipv6.conf.all.mc_forwarding" "net.ipv4.conf.all.accept_redirects" "net.ipv6.conf.all.accept_redirects" "net.ipv4.conf.all.secure_redirects" "net.ipv4.conf.all.send_redirects")
		for ((i=0;i<${#array[@]};i++))
		do
		{
			grep ${array[$i]} $absPath | grep -v "#" > /dev/null
			if [ $? -eq 0 ]; then
			{
				val=`grep ${array[$i]} $absPath | grep -v "#"` > /dev/null
				newval=`echo $val | awk -F"=" '{print $2}'`
				if [ $newval -ne 0 ]; then
				{
					echo -e "$FCyellow Found ${array[$i]} . Commenting it and putting a new value $endFC" | tee -a $logFileAbsPath
					sed -i '/'${array[$i]}'/ s/^/#/g' $absPath
					if [ $? -eq 0 ]; then
					{
						echo -e "$FCyellow Successfully commented ${array[$i]}. Putting a new entry for same $endFC" | tee -a $logFileAbsPath
						echo "${array[$i]}=0" >> $absPath
						echo -e "$FCgreen Successfully added a new entry for  ${array[$i]} $endFC" | tee -a $logFileAbsPath
					}
					else
					{
						echo -e "$FCred Could not comment ${array[$i]} line in $absPath $endFC" | tee -a $logFileAbsPath
					}
					fi
				}
				else
				{
					echo -e "$FCyellow Value for ${array[$i]} is 0, there is not need to change the value $endFC" | tee -a $logFileAbsPath
				}
				fi
			}
			else
			{
				echo -e "$FCyellow Putting a new entry for ${array[$i]} $endFC" | tee -a $logFileAbsPath
				echo "${array[$i]}=0" >> $absPath
				echo -e "$FCgreen Successfully added a new entry for  ${array[$i]} $endFC" | tee -a $logFileAbsPath
			}
			fi
		}
		done
	}
        check_file_exists $absPath
	if [ $? -eq 0 ]; then
	{
		checkSetVal
		sysctl -a
	}
	else
	{
		echo -e "$FCred Could not find the file $filename at $absPath $endFC" | tee -a $logFileAbsPath
	}
	fi
}

##Part 4 : Operational Security

logRotate()
{
	fileName="logrotate.conf"
	filePath="/etc"
        absPath=$filePath"/"$fileName
        check_file_exists $absPath
	if [ $? -eq 0 ]; then
	{
		array=("weekly" "rotate" "compress")
		for ((i=0;i<${#array[@]};i++))
		do
			grep ${array[$i]} $absPath | grep -v "#" > /dev/null
			if [ $? -eq 0 ]; then
			{
				if [ ${array[$i]} == "weekly" ]; then
				{
					sed -i 's/'${array[$i]}'/daily/g' $absPath
					if [ $? -eq 0 ]; then
					{
						echo -e "$FCgreen Successfully changed the log rotation to daily $endFC" | tee -a $logFileAbsPath
					}
					else
					{
						echo -e "$FCred Could not change the log rotation to daily $endFC" | tee -a $logFileAbsPath
					}
					fi
				}
				elif [ ${array[$i]} == "rotate" ]; then
				{
					sed -i '/'${array[$i]}'/ s/^/#/g' $absPath
					if [ $? -eq 0 ]; then
					{
						echo "rotate 45" >> $absPath
						echo -e "$FCgreen Successfully set the log retention period to 45 $endFC" | tee -a $logFileAbsPath
					}
					else
					{
						echo -e "$FCred Could not comment log retention period $endFC" | tee -a $logFileAbsPath
					}
					fi
				}
				else
				{
					sed -i '/'${array[$i]}'/d' $absPath
					echo "#uncomment this if you want your log files compressed" >> $absPath
					echo "compress" >> $absPath
					echo -e "$FCgreen Successfully compressed the log files $endFC" | tee -a $logFileAbsPath
				}
				fi
			}
			else
			{
				if [ ${array[$i]} == "weekly" ]; then
				{
					grep "daily" $absPath > /dev/null
					if [ $? -eq 0 ]; then
					{
						echo -e "$FCyellow  Log rotation is already set to daily $endFC" | tee -a $logFileAbsPath
					}
					else
					{
						echo "daily" >> $absPath
						echo -e "$FCgreen Successfully changed the log rotation to daily $endFC" | tee -a $logFileAbsPath
					}
					fi
				}
				elif [ ${array[$i]} == "rotate" ]; then
				{
					echo "rotate 45" >> $absPath
					echo -e "$FCgreen Successfully set the log retention period to 45 $endFC" | tee -a $logFileAbsPath
				}
				else
				{
					echo "compress" >> $absPath
					echo -e "$FCgreen Successfully compressed the log files $endFC" | tee -a $logFileAbsPath
				}
				fi
			}
			fi
		done
	}
	else
	{
		echo -e "$FCred Could not find file $filename at $absPath path $endFC" | tee -a $logFileAbsPath
	}
	fi
}

disableTelnet()
{
	fileName="telnet"
	filePath="/etc/xinetd.d"
        absPath=$filePath"/"$fileName
	status="disable"
	service="telnet"
	if [ ! -e $absPath ]; then
	{
		echo -e "$FCyellow Could not find file $filename at $absPath path . Hence no issues $endFC" | tee -a $logFileAbsPath
		
	}
	else
	{
		val=`grep -i $status $absPath | xargs | cut -d "=" -f2 | xargs`
		if [ $val = "yes" ]; then
		{
			echo -e "$FCyellow $service is already disabled in this server $endFC" | tee -a $logFileAbsPath
		}
		else
		{
			sed -i '/'$status'/ s/no/yes/g' $absPath > /dev/null
			if [ $? -eq 0 ]; then
			{
				echo -e "$FCgreen Successfully disabled the status of telnet daemon $endFC" | tee -a $logFileAbsPath
				/etc/init.d/xinetd stop > /dev/null
			}
			else
			{
				echo -e "$FCred Could not disable the status of telnet daemon. Please check this manually $endFC" | tee -a $logFileAbsPath
			}
			fi
		}
		fi
	}
	fi	
}

###### Following script is authored by Amol Jadhav  ######



disableSSHRhost()
{		
		echo -e "$FCyellow Checking SSH Rhost functionality $endFC"
        fileName="sshd_config"
        filePath="/etc/ssh"
        absPath=$filePath"/"$fileName
        check_file_exists $absPath

        if [ $? -eq 0 ]; then
        {
                grep -i IgnoreRhosts /etc/ssh/sshd_config | grep -v "#" > /dev/null
                if [ $? -eq 0 ]; then
                {
                        val=`grep -i IgnoreRhosts /etc/ssh/sshd_config | grep -v "#"` > /dev/null
                        newval=`echo $val | awk -F" " '{print $2}'`
                        if [ $newval != "yes" ]; then
                        {
                        echo -e "$FCred SSH RHosts functionality is enabled, Disabling it $endFC" |  tee -a $logFileAbsPath
                        sed -i '/IgnoreRhosts/ s/yes/no/g' $absPath
                        echo -e "$FCgreen Successfully disbaled Rhost funtionality $endFC" | tee -a $logFileAbsPath
                        #systemctl restart sshd.service
			/etc/init.d/sshd restart
                        }
                        else
                        {
                                echo -e "$FCyellow Rhost functionality is already disabled $endFC" | tee -a $logFileAbsPath
                        }
                fi
                }
                else
                {
                        echo "IgnoreRhosts yes" >> $absPath
                        echo -e "$FCgreen Successfully disbaled Rhost functionality $endFC" | tee -a $logFileAbsPath
                        service sshd restart
                }
                fi
        }
        else
        {
                echo -e "$FCred Could not find the file $fileName at $absPath path $endFC" | tee -a $logFileAbsPath
        }
        fi
}

setCronUserRoot()
{
        fileName="cron.d"
        filePath="/etc"
        absPath=$filePath"/"$fileName
        check_file_exists $absPath
echo -e "$FCyellow Checking user ownership of files in $absPath $endFC"
var=`ls -l $absPath/* | awk -F" " '{print $3}'`
arr=($var)

for item in "${arr[@]}"
do
	if [ $item = "root" ]; then
		{
		continue
		}
	else
		{
		echo -e "$FCyellow One of the File in $absPath/ is  owned by $item user, Changing owner to root $endFC" |  tee -a $logFileAbsPath
		chown root:root $absPath/*
		if [ $? -eq 0 ]; then
			{
			echo -e "$FCgreen Successfully changed user owner for all files in $absPath/ to user root $endFC" | tee -a $logFileAbsPath
			}
		else
			{
			echo -e "$FCred Could not change owner to all files in $absPath/ $endFC" | tee -a $logFileAbsPath
			}
		fi
		}
	fi
done
}

setCronGroupRoot()
{

        fileName="cron.d"
        filePath="/etc"
        absPath=$filePath"/"$fileName
        check_file_exists $absPath
echo -e "$FCyellow Checking group ownership of files in $absPath $endFC"
var=`ls -l $absPath/* | awk -F" " '{print $4}'`
arr=($var)
#echo ${arr[*]}
for item in "${arr[@]}"
do
        if [ $item = "root" ]; then
                {
                continue
                }
        else
                {
                echo -e "$FCyellow One of the File in $absPath/ is  owned by $item group, Changing group owner to root $endFC"| tee -a $logFileAbsPath
                chown root:root $absPath/*
                if [ $? -eq 0 ]; then
                        {
                        echo -e "$FCgreen Successfully changed group owner for all files in $absPath/ to user root $endFC"| tee -a $logFileAbsPath
                        }
                else
                        {
                        echo -e "$FCred Could not change owner to all files in $absPath/ $endFC"| tee -a $logFileAbsPath
                        }
                fi
                }
        fi
		done
}

setCronWritePerms()
{
        fileName="cron.d"
        filePath="/etc"
        absPath=$filePath"/"$fileName
        check_file_exists $absPath
echo -e "$FCyellow Checking write permissions of files in $absPath $endFC"
count=`ls -l $absPath/* | awk -F" " '{print $1}' | wc -l`

for (( i=$count; i>=1; i-- ))
do
        var1=`ls -l $absPath/* | awk -F" " '{print $1}'| tail -$i | head -1`
	var2=`ls -l $absPath/* | awk -F" " '{print $9}' | tail -$i | head -1`
	arr1+=($var1:$var2)
done
#echo ${arr1[*]}

for item in "${arr1[@]}"
do
	permissions=`echo $item | awk -F":" '{print $1}'`
	filename=`echo $item | awk -F":" '{print $2}'`
	
	root_wr_perms=`echo $permissions | grep -o . | sed -n '3p'`
	group_wr_perms=`echo $permissions | grep -o . | sed -n '6p'`
	others_wr_perms=`echo $permissions | grep -o . | sed -n '9p'`

	allWrite_perms=($root_wr_perms$group_wr_perms$others_wr_perms)
	
	if [ $allWrite_perms != "w--" ]; then
                {
                echo -e "$FCyellow $filename has write permission to groups or others, Updating write permissions for root only write access $endFC" | tee -a $logFileAbsPath
		chmod u+w $filename
		chmod g-w $filename
		chmod o-w $filename
	        check=`ls -l /etc/cron.d/* | grep $filename | awk -F" " '{print $1}'`
	        root_wr_perms=`echo $check | grep -o . | sed -n '3p'`
	        group_wr_perms=`echo $check | grep -o . | sed -n '6p'`
        	others_wr_perms=`echo $check | grep -o . | sed -n '9p'`

	        allWrite_perms=($root_wr_perms$group_wr_perms$others_wr_perms)

        	if [ $allWrite_perms != "w--" ]; then
          		{
	                echo -e "$FCred Could not successfully change write permissions on $filename" | tee -a $logFileAbsPath
	                }
        	else
                	{
	                echo -e "$FCgreen Successfully updated write permisisons on $filename: only root user has write access $endFC" | tee -a $logFileAbsPath
	                }
	        fi
                }
	fi
done
}

setUmask()
{
        ##check if functions file exists
        fileName="functions"
        filePath="/etc/rc.d/init.d"
        absPath=$filePath"/"$fileName
        check_file_exists $absPath
	if [ $? -eq 0 ]; then
        {
	    echo -e "$FCyellow Checking umask value in $absPath $endFC"
		val=`grep umask /etc/rc.d/init.d/functions | grep -v "#" | awk -F" " '{print $2}'` > /dev/null
		if [ ! -z $val ]; then
                {
		if [ $val != 022 ]; then
		{
			if [ $val -lt 022 ]; then
			{
				sed -i '/umask/ s/^/#/g' $absPath
				if [ $? -eq 0 ]; then
				{
					echo "umask 022" >> $absPath
					echo -e "$FCgreen Successfully changed umask value to 022 $endFC" | tee -a $logFileAbsPath
				}
				else
				{
					echo -e "$FCred Could not Successfully changed umask value to 022 $endFC" | tee -a $logFileAbsPath
				}
				fi
			}
			else
			{
				echo -e "$FCyellow umask value is already strict than 022 $endFC" | tee -a
			}
			fi
		}
		else
		{
			 echo -e "$FCyellow umask value is already set to 022 $endFC" | tee -a $logFileAbsPath
		}
		fi
		}
		else
		{          
     	                 echo "umask 022" >> $absPath
                         echo -e "$FCgreen Successfully changed umask value to 022 $endFC" | tee -a $logFileAbsPath
          	}
		fi		
        }
        else
        {
                echo -e "$FCred File $absPath does not exists $endFC" | tee -a $logFileAbsPath
                echo -e "$FCred umask value could not check as $absPath does not exist $endFC" | tee -a  $logFileAbsPath
        }
        fi
}

setPassAlgoMD5()
{
				echo -e "$FCyellow Checking Password algorithm... $endFC"
                fileName="authconfig"
                filePath="/etc/sysconfig"
                absPath=$filePath"/"$fileName
                check_file_exists $absPath
                val=`grep -i PASSWDALGORITHM /etc/sysconfig/authconfig | grep -v "#" | xargs` > /dev/null
                if [ -z $val ]; then
                {
                algo="not-set"
                }
                else
                {
                algo=`echo $val | awk -F"=" '{print $2}' | xargs`
                }
                fi
                echo -e "$FCyellow ___________________ $algo _________________________ $endFC"
                if [ $? -eq 0 ]; then
                {
                        if [ $algo = "sha512" ] || [ $algo = "sha256" ] || [ $algo = "bigcrypt" ]; then
                        {
                                echo -e "$FCyellow Password algorithm is better than md5, no need to change $endFC" | tee -a $logFileAbsPath
                        }
                        elif [ $algo = "md5" ]; then
                        {
                                echo -e "$FCyellow Password algorithm is set to md5, no need to change $endFC" | tee -a $logFileAbsPath
                        }
                        elif [ $algo = "descrypt" ] || [ $algo = "not-set" ]; then
                        {
                                echo -e "$FCyellow Password algorithm is either not set ot set to DES, stronger algorithm needs to be set $endFC" | tee -a $logFileAbsPath
                                echo -e "$FCyellow Updating password algorithm to MD5 $endFC"
                                sed -i '/PASSWDALGORITHM/ s/^/#/g' $absPath
                                if [ $? -eq 0 ]; then
                                {
                                        echo "PASSWDALGORITHM=md5" >> $absPath
                                        authconfig --updateall
                                        echo -e "$FCgreen Successfully updated password algorithm to MD5 or better $endFC" | tee -a $logFileAbsPath
                                 }
                                else
                                {
                                        echo -e "$FCyellow Could not set the password algorithm to MD5 or better $endFC" | tee -a $logFileAbsPath
                                }
                                fi
                        }
                        else
                        {
                                echo -e "FCred Could not find any Standard password algorithm set in $absPath $endFC" | tee -a $logFileAbsPath
                        }
                        fi
                }
                else
                {
                        echo -e "$FCred Could not find password algorithm applied to system in  $absPath $endFC" | tee -a $logFileAbsPath
                }
                fi
}


checkconfigSmb()
{
echo -e "$FCyellow Checking configuration of Samba service... $endFC"	
chkconfig --list smb 2> /dev/null
if [ $? -eq 0 ]; then
{
         echo -e "$FCyellow Samba serivce is enabled in chkconfig, Starting to disable it $endFC" | tee -a $logFileAbsPath
		 chkconfig --del smb
        chkconfig --list smb > /dev/null
        if [ $? -eq 0 ]; then
        {
                echo -e "$FCred Could not disable samba service in chkconfig $endFC" | tee -a $logFileAbsPath
        }
        else
        {
                echo -e "$FCgreen Disabled samba service in chkconfig $endFC" | tee -a $logFileAbsPath
        }
        fi
}
else
{
        echo -e "$FCgreen Samba service is not configured in chkconfig $endFC" | tee -a $logFileAbsPath
}
fi
}

disableSendmail()
{
echo -e "$FCyellow Checking sendmail service... $endFC"
echo -e "$FCyellow Checking presence of sendmail package on system $endFC"
val=`rpm -qa | grep sendmail` > /dev/null
if [ $? -eq 0 ]; then
        {
                if [[ $val == *"sendmail"* ]]; then
                        {
                        echo -e "$FCyellow Sendmail service is installed on this machine $endFC"
                        echo -e "$FCyellow Uninstalling Sendmail service $endFC"
                        rpm -e $val
                        if [ $? -eq 0 ]; then
                                {
                                check=`rpm -qa | grep sendmail` > /dev/null
                                 if [[ $check == *"sendmail"* ]]; then
                                        {
                                        echo -e "$FCred Could not uninstall package sendmail from system $endFC"
                                        }
                                else
                                        {
                                        echo -e "$FCgreen Successfully uninstalled package sendmail from system $endFC"
                                        }
                                fi
                                }
                        else
                                {
                                echo -e "$FCred Could not find package sendmail from system $endFC"
                                }
                        fi
                        }
                fi
        }
else
{
echo -e "$FCyellow Sendmail package is not installed on system $endFC" | tee -a $logFileAbsPath
}
fi
}

## Check ownership and permission of bashrc and bash_profile files of all users ##

check_homefiles_perms()
{
        parDir="/home"
        filelist=(".bashrc" ".bash_profile")

        for ((j=0;j<${#filelist[@]};j++))
        {
        max=`ls -lrth /home | grep -v "total" | wc -l`
        tmpFile="/tmp/file"
        file=${filelist[$j]}
        ls -lrth /home | grep -v "total"  | awk '{print $NF}' > $tmpFile
        for ((i=1;i<=$max;i++))
        {
                userDir=`head -$i $tmpFile | tail -1`
                cd $parDir/$userDir
                filepath=$parDir/$userDir/$file
                if [ -e $filepath ]; then
                {
                chown $userDir:$userDir $filepath
                octal_perms=`stat -c "%a" $filepath`
                if [ $octal_perms>755 ]; then
                        {
                        chmod 755 $filepath
                        }
                fi
                if [ $octal_perms<755 ]; then
                        {
                        others_perms=`echo "$octal_perms % 10" | bc`
                        temp_perms=`echo "$octal_perms % 100" | bc`
                        group_perms=`echo $((temp_perms/10))`
                        if [ $others_perms>5 ]; then
                                {
                                chmod o+rx $filepath
                                }
                        fi
                        if [ $group_perm>5 ]; then
                                {
                                chmod g+rx $filepath
                                }
                        fi
                        }
                echo -e "$FCgreen owner/group of user $userDir on file ${filelist[$j]} is set to respective users and permission set to 755 or stricter $endFC" | tee -a $logFileAbsPath
                fi
                }
                else
                {
                echo -e "$FCyellow File ${filelist[$j]} is not Present for user $userDir, Hence no  issues $endFC" | tee -a $logFileAbsPath
                }
                fi
        }
        rm -frv $parDir/$userDir/5 > /dev/null
        rm -frv $parDir/$userDir/755 > /dev/null
        rm -frv $tmpFile > /dev/null

}
}


## Check ownership and permisions of  netrc and telnetrc files of all users ##

check_netrcTelnetrc_files()
{
        parDir="/home"
        filelist=(".netrc" ".telnetrc")

        for ((j=0;j<${#filelist[@]};j++))
        {
        max=`ls -lrth /home | grep -v "total" | wc -l`
        tmpFile="/tmp/file"
        file=${filelist[$j]}
        ls -lrth /home | grep -v "total"  | awk '{print $NF}' > $tmpFile
        for ((i=1;i<=$max;i++))
        {
                userDir=`head -$i $tmpFile | tail -1`
                cd $parDir/$userDir
                filepath=$parDir/$userDir/$file
                if [ -e $filepath ]; then
                {
                chown $userDir:$userDir $filepath
                octal_perms=`stat -c "%a" $filepath`
                if [ $octal_perms>700 ]; then
                        {
                        chmod 700 $filepath
                        }
                fi
                if [ $octal_perms<700 ]; then
                        {
                        others_perms=`echo "$octal_perms % 10" | bc`
                        temp_perms=`echo "$octal_perms % 100" | bc`
                        group_perms=`echo $((temp_perms/10))`
                        if [ $others_perms>0 ]; then
                                {
                                chmod o-rwx $filepath
                                }
                        fi
                        if [ $group_perm>0 ]; then
                                {
                                chmod g-rwx $filepath
                                }
                        fi
                        }
                echo -e "$FCgreen owner/group of user $userDir on file ${filelist[$j]} is set to respective users and permission set to 700 or stricter $endFC" | tee -a $logFileAbsPath
                fi
                }
                else
                {
                echo -e "$FCyellow File ${filelist[$j]} is not Present for user $userDir, Hence no  issues $endFC" | tee -a $logFileAbsPath
                }
                fi
        }
        rm -frv $parDir/$userDir/0 > /dev/null
        rm -frv $parDir/$userDir/700 > /dev/null
        rm -frv $tmpFile > /dev/null

}
}

## Check onwership and permissions of home directories of all users

home_directory_perms()
{
        parDir="/home"
        max=`ls -lrth /home | grep -v "total" | wc -l`
        tmpFile="/tmp/file"
        ls -lrth /home | grep -v "total"  | awk '{print $NF}' > $tmpFile
        for ((i=1;i<=$max;i++))
        do
                userDir=`head -$i $tmpFile | tail -1`
                filepath=$parDir/$userDir
                if [ -e $filepath ]; then
                {
                                chown $userDir:$userDir $filepath
                octal_perms=`stat -c "%a" $filepath`
                if [ $octal_perms>755 ]; then
                        {
                        chmod 755 $filepath
                        }
                fi
                if [ $octal_perms<755 ]; then
                        {
                        others_perms=`echo "$octal_perms % 10" | bc`
                        temp_perms=`echo "$octal_perms % 100" | bc`
                        group_perms=`echo $((temp_perms/10))`
                        if [ $others_perms>5 ]; then
                                {
                                chmod o+rx $filepath
                                }
                        fi
                        if [ $group_perm>5 ]; then
                                {
                                chmod g+rx $filepath
                                }
                        fi
                        }
                echo -e "$FCgreen Home directory of user $userDir is set to respective users and permission set to 755 or stricter $endFC" | tee -a $logFileAbsPath
                fi
                }
                else
                {
                echo -e "$FCyellow File ${filelist[$j]} is not Present for user $userDir, Hence no  issues $endFC" | tee -a $logFileAbsPath
                }
                fi



        done
	rm -frv $parDir/$userDir/5 > /dev/null
        rm -frv $parDir/$userDir/755 > /dev/null
        rm -frv $tmpFile > /dev/null 
}

## Checking permissions of .ssh directory for all users ##

check_sshDir_perms()
{
         if [ -e /root/.ssh ]; then
                {
                        chmod -R 700 /root/.ssh
                        echo -e "$FCgreen Directory /root/.ssh for user root, updated with 700 permissions recursively $endFC" | tee -a $logFileAbsPath

                }
                else
                {
                echo -e "$FCyellow Directory /root/.ssh is not Present for user root, Hence not checked permissions $endFC" | tee -a $logFileAbsPath
                }
                fi

        parDir="/home"
        max=`ls -lrth /home | grep -v "total" | wc -l`
        tmpFile="/tmp/file"
        file=.ssh
        ls -lrth /home | grep -v "total"  | awk '{print $NF}' > $tmpFile
        for ((i=1;i<=$max;i++))
        {
                userDir=`head -$i $tmpFile | tail -1`
                cd $parDir/$userDir
                filepath=$parDir/$userDir/$file
                if [ -e $filepath ]; then
                {
				chmod -R 700 $filepath
				echo -e "$FCgreen Directory $filepath for user $userDir, updated with 700 permissions recursively $endFC" | tee -a $logFileAbsPath
                }
                else
                {
                echo -e "$FCyellow Directory $filepath is not Present for user $userDir, Hence not checked permissions $endFC" | tee -a $logFileAbsPath
                }
                fi
        }
        rm -frv $tmpFile > /dev/null
}


## Function calls##

Passwd_Maxi_Age
BlankPassNotAllowed
PasswordComplexity
passwordHistory
passwdMinDays
passwdMinLength
rsyslogAuth
checkFilePerm
disableRootLogin
bashrcOwnership            
networkSecurity
logRotate
disableTelnet

disableSSHRhost
setCronUserRoot
setCronGroupRoot
setCronWritePerms
setUmask
setPassAlgoMD5
checkconfigSmb
disableSendmail
check_homefiles_perms
check_netrcTelnetrc_files
home_directory_perms
check_sshDir_perms
